#include <stdint.h>
#include <stdio.h>
#include <link.h>
#include <gelf.h>
#include <elf.h>
#include <errno.h>

#include "include/context.h"
#include "include/process.h"
#include "include/rtld.h"
#include "include/log.h"
#include "include/xmalloc.h"
int j = 0;

struct r_debug_32
  {
    int r_version;		/* Version number for this protocol.  */

    uint32_t r_map;	/* Head of the chain of loaded objects.  */

    /* This is the address of a function internal to the run-time linker,
       that will always be called when the linker begins to map in a
       library or unmap it, and again when the mapping change is complete.
       The debugger can set a breakpoint at this address if it wants to
       notice shared object mapping changes.  */
    Elf32_Addr r_brk;
    enum
      {
    /* This state value describes the mapping change taking place when
       the `r_brk' address is called.  */
    RT_CONSISTET,		/* Mapping change is complete.  */
    RTADD,			/* Beginning to add a new object.  */
    RT_ELETE		/* Beginning to remove an object mapping.  */
      } r_state;

    Elf32_Addr r_ldbase;	/* Base address the linker is loaded at.  */
  };

struct link_map_32
  {
    /* These first few members are part of the protocol with the debugger.
       This is the same format used in SVR4.  */

    Elf32_Addr l_addr;		/* Difference between the address in the ELF
				   file and the addresses in memory.  */
    char *l_name;		/* Absolute file name object was found in.  */
    Elf32_Dyn *l_ld;		/* Dynamic section of the shared object.  */
    struct link_map_32 *l_next, *l_prev; /* Chain of loaded objects.  */
  };

struct link_map_32_2
  {
    /* These first few members are part of the protocol with the debugger.
       This is the same format used in SVR4.  */
	Elf32_Addr l_addr;
	uint32_t l_name;
	uint32_t l_ld;
	uint32_t l_next, l_prev;
  };
/*static int rtld_get_dyn(struct process_ctx_s *ctx, const void *addr, GElf_Dyn *dyn)
{
	return process_read_data(ctx, (uint64_t)addr, dyn, sizeof(*dyn));
}*/

static int rtld_get_dyn(struct process_ctx_s *ctx, const void *addr, Elf32_Dyn *dyn)
{
	return process_read_data(ctx, (uint64_t)addr & 0xffffffff, dyn, sizeof(*dyn));
}

/*static int64_t rtld_dynamic_tag_val(struct process_ctx_s *ctx,
				    const GElf_Dyn *l_ld, uint32_t d_tag)
{
	printf("begin - rtld_dynamic_tag_val\n"); //printf("d.d_tag[%d] = %lu\n", j, l_ld->d_tag);
	GElf_Dyn dyn;
	const GElf_Dyn *d;
	int err;
	//static int i = 0;
	for (d = l_ld; ; d++) {
		
		//printf("infinity - 0 - rtld_dynamic_tag_val\n");
		err = rtld_get_dyn(ctx, d, &dyn);
		j++;
		if (j < 10){
			printf("dyn.d_tag[%d] = %lu\n", j, dyn.d_tag);
			printf("p : dyn_addr[%d] = %p\n", j, (void*)&dyn);
			//printf("x : dyn_addr[%d] = %x\n", j, (uint64_t)dyn);
			printf("d[%d] = %p\n", j, (void*)d);
			printf("sizeof(*dyn)[%d] = %lu\n", j, sizeof(dyn));
			printf("sizeof(Elf32_Dyn)[%d] = %lu\n", j, sizeof(Elf32_Dyn));
			
		}
		//printf("dyn.d_tag = %lu\n", dyn.d_tag);
		//printf("infinity - 1 - rtld_dynamic_tag_val\n");
		if (err){
			printf("infinity - 2 - rtld_dynamic_tag_val\n");
			return err;
		}
		if (dyn.d_tag == DT_NULL){
			printf("infinity - 3 - rtld_dynamic_tag_val\n");
			break;
		}

		if (dyn.d_tag == d_tag){
			printf("infinity - 4 - rtld_dynamic_tag_val\n");
			return dyn.d_un.d_val;
		}
		//if(i < 30)
		//{
			//break;
		//}
	}
	printf("end - rtld_dynamic_tag_val\n");
	return -ENOENT;
}*/

static int64_t rtld_dynamic_tag_val(struct process_ctx_s *ctx,
				    const Elf32_Dyn *l_ld, uint32_t d_tag)
{
	printf("begin - rtld_dynamic_tag_val\n"); 	
	//l_ld = (Elf32_Dyn *)(((uintptr_t)l_ld) >> 32);
	//l_ld = (void*)((uintptr_t)l_ld & 0xffffffff);
	//l_ld++;
	Elf32_Dyn dyn;
	const Elf32_Dyn *d;
	int err;
	//static int i = 0;
	for (d = l_ld; ; d++) {
		
		//printf("infinity - 0 - rtld_dynamic_tag_val\n");
		err = rtld_get_dyn(ctx, d, &dyn);
		j++;
		if (j < 10000){
			printf("dyn.d_tag[%d] = %d\n", j, dyn.d_tag);
			printf("dyn_addr[%d] = %p\n", j, (void*)&dyn);
			printf("d = %p\n", d);
		}
		//printf("dyn.d_tag = %lu\n", dyn.d_tag);
		//printf("infinity - 1 - rtld_dynamic_tag_val\n");
		if (err){
			printf("infinity - 2 - rtld_dynamic_tag_val\n");
			return err;
		}
		if (dyn.d_tag == DT_NULL){
			printf("infinity - 3 - rtld_dynamic_tag_val\n");
			break;
		}

		if (dyn.d_tag == d_tag){
			printf("infinity - 4 - rtld_dynamic_tag_val\n");
			return dyn.d_un.d_val;
		}
		//if(i < 30)
		//{
			//break;
		//}
	}
	printf("end - rtld_dynamic_tag_val\n");
	return -ENOENT;
}

static int rtld_get_lm(struct process_ctx_s *ctx, uint32_t addr, struct link_map_32_2 *lm)
{
	printf("Enter into get_lm!!!\n");
	return process_read_data(ctx, (uint64_t)addr /*& 0xffffffff*/, lm, sizeof(*lm));
}

int rtld_needed_array(struct process_ctx_s *ctx, uint64_t _r_debug_addr,
		      uint64_t **needed_array)
{
	struct link_map_32_2 link_map, *lm = &link_map;
	//uint32_t lum_32  = (uint32_t)(uintptr_t)lm; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//struct link_map_32 *lm_32 = (void *)(uintptr_t)(lum_32); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	uint32_t lm_addr;
	int err, nr = 0;
	const int step = 10;
	uint64_t *arr = NULL;
	
	printf("0 - rtld_needed_array; before - process_read_data\n");
	err = process_read_data(ctx, _r_debug_addr + offsetof(struct r_debug_32, r_map),
				&lm_addr, sizeof(lm_addr));
	printf("offsetof(struct r_debug_32, r_map) = %lu\n", offsetof(struct r_debug_32, r_map));
		
	printf("1 - rtld_needed_array; after - process_read_data\n");
	printf("sizeof(struct link_map_32_2) = %lu\n", sizeof(struct link_map_32_2));
	if (err)
		return err;

	do {

		printf("2 - infinity - rtld_needed_array\n");
		int64_t dt_symtab_addr;
		printf("--->err = rtld_get_lm(ctx, lm_addr, lm);\n");
		printf("	lm_address = %p\n", lm);
		printf("	lm->l_ld_address = %x\n", lm->l_ld);
		err = rtld_get_lm(ctx, lm_addr, lm);
		printf("instruction done\n");
		printf("	lm_address = %p\n", lm);
		printf("	lm->l_ld_address = %x\n", lm->l_ld);
		//printf("	lm->l_name_address = %p\n", (void*)lm->l_name);
		printf("err = rtld_get_lm(ctx, lm_addr, lm);--->\n");
		printf("3 - infinity - rtld_needed_array\n");

		if (err)
			return err;

		/* We rely upon presense of DT_SYMTAB, because it's mandatory */
		//printf("4 - infinity - rtld_needed_array\n");
		printf("lm_value_transfer = 0x%lx\n", *(uint64_t *)lm);

		printf("--->dt_symtab_addr = rtld_dynamic_tag_val(ctx, lm->l_ld, DT_SYMTAB);\n");
		dt_symtab_addr = rtld_dynamic_tag_val(ctx, (void*)(uintptr_t)lm->l_ld, DT_SYMTAB);
		printf("dt_symtab_addr = %lu\n", dt_symtab_addr);
		printf("dt_symtab_addr = rtld_dynamic_tag_val(ctx, lm->l_ld, DT_SYMTAB);--->\n");
		printf("5 - infinity - rtld_needed_array\n");
		if (dt_symtab_addr == -ENOENT){
			printf("hahaha - classic\n");			
			return dt_symtab_addr;
		}

		/* Check dt_symtab_addr for being above link addr.
		 * This is diferent in VDSO, which has negative or small
		 * address which is offsets from base.
		 */

		printf("(int64_t)lm->l_addr = %lu\n", (int64_t)lm->l_addr);
		printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!dt_symtab_addr = %lu\n", dt_symtab_addr);
		printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!(int64_t)lm->l_addr = %lu\n", (int64_t)lm->l_addr);
		if (dt_symtab_addr >= (int64_t)lm->l_addr) { printf("sukkkkkkkkkkkkkkkkkkkkka\n");
			if ((nr % step) == 0) {
				arr = xrealloc(arr, step * sizeof(uint32_t));
				if (!arr)
					return -ENOMEM;
			}
			arr[nr] = dt_symtab_addr;
			printf("**********************************************arr[%d] = %lu\n", nr, arr[nr]);
			nr++;
		}
		lm_addr = lm->l_next;
	} while (lm_addr);

	*needed_array = arr;
	return nr;
}
