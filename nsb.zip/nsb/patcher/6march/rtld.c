#include <stdint.h>
#include <stdio.h>
#include <link.h>
#include <gelf.h>
#include <elf.h>
#include <errno.h>

#include "include/context.h"
#include "include/process.h"
#include "include/rtld.h"
#include "include/log.h"
#include "include/xmalloc.h"
int j = 0;

struct r_debug_32
  {
    int r_version;		/* Version number for this protocol.  */

    uint32_t r_map;	/* Head of the chain of loaded objects.  */

    /* This is the address of a function internal to the run-time linker,
       that will always be called when the linker begins to map in a
       library or unmap it, and again when the mapping change is complete.
       The debugger can set a breakpoint at this address if it wants to
       notice shared object mapping changes.  */
    Elf32_Addr r_brk;
    enum
      {
    /* This state value describes the mapping change taking place when
       the `r_brk' address is called.  */
    RT_CONSISTET,		/* Mapping change is complete.  */
    RTADD,			/* Beginning to add a new object.  */
    RT_ELETE		/* Beginning to remove an object mapping.  */
      } r_state;

    Elf32_Addr r_ldbase;	/* Base address the linker is loaded at.  */
  };

struct link_map_32
  {
    /* These first few members are part of the protocol with the debugger.
       This is the same format used in SVR4.  */

    Elf32_Addr l_addr;		/* Difference between the address in the ELF
				   file and the addresses in memory.  */
    char *l_name;		/* Absolute file name object was found in.  */
    Elf32_Dyn *l_ld;		/* Dynamic section of the shared object.  */
    struct link_map_32 *l_next, *l_prev; /* Chain of loaded objects.  */
  };

struct link_map_32_2
  {
    /* These first few members are part of the protocol with the debugger.
       This is the same format used in SVR4.  */
	Elf32_Addr l_addr;
	uint32_t l_name;
	uint32_t l_ld;
	uint32_t l_next, l_prev;
  };
/*static int rtld_get_dyn(struct process_ctx_s *ctx, const void *addr, GElf_Dyn *dyn)
{
	return process_read_data(ctx, (uint64_t)addr, dyn, sizeof(*dyn));
}*/

static int rtld_get_dyn(struct process_ctx_s *ctx, uint32_t addr, Elf32_Dyn *dyn)
{
	return process_read_data(ctx, addr, dyn, sizeof(*dyn));
}

static int32_t rtld_dynamic_tag_val(struct process_ctx_s *ctx,
				    uint32_t l_ld, uint32_t d_tag)
{
	//printf("begin - rtld_dynamic_tag_val\n"); //printf("d.d_tag[%d] = %lu\n", j, l_ld->d_tag);
	Elf32_Dyn dyn;
	uint32_t d;
	int err;
	//static int i = 0;
	for (d = l_ld; ;) {
		
		//printf("infinity - 0 - rtld_dynamic_tag_val\n");
		err = rtld_get_dyn(ctx, d, &dyn);
		j++;
		if (j < 100){
			//printf("dyn.d_tag[%d] = %u\n", j, dyn.d_tag);
			/*printf("p : dyn_addr[%d] = %p\n", j, (void*)&dyn);
			//printf("x : dyn_addr[%d] = %x\n", j, (uint64_t)dyn);
			printf("d[%d] = %p\n", j, (void*)d);
			printf("sizeof(*dyn)[%d] = %lu\n", j, sizeof(dyn));
			printf("sizeof(Elf32_Dyn)[%d] = %lu\n", j, sizeof(Elf32_Dyn));*/
			
		}
		//printf("dyn.d_tag = %lu\n", dyn.d_tag);
		//printf("infinity - 1 - rtld_dynamic_tag_val\n");
		if (err){
			printf("infinity - 2 - rtld_dynamic_tag_val\n");
			return err;
		}
		if (dyn.d_tag == DT_NULL){
			printf("infinity - 3 - rtld_dynamic_tag_val\n");
			break;
		}

		if (dyn.d_tag == d_tag){
			printf("dyn.d_tag[%d] = %u\n", j, dyn.d_tag);
			return dyn.d_un.d_ptr;
		}
		d += 8;
	}
	printf("end - rtld_dynamic_tag_val\n");
	return -ENOENT;
}

/*static int32_t rtld_dynamic_tag_val(struct process_ctx_s *ctx,
				    const Elf32_Dyn *l_ld, uint32_t d_tag)
{
	printf("begin - rtld_dynamic_tag_val\n"); 	
	//l_ld = (Elf32_Dyn *)(((uintptr_t)l_ld) >> 32);
	l_ld = (void*)((uintptr_t)l_ld & 0xffffffff);
	//l_ld++;
	Elf32_Dyn dyn;
	const Elf32_Dyn *d;
	int err;
	//static int i = 0;
	for (d = l_ld; ; d++) {
		
		//printf("infinity - 0 - rtld_dynamic_tag_val\n");
		err = rtld_get_dyn(ctx, d, &dyn);
		j++;
		if (j < 10000){
			printf("dyn.d_tag[%d] = %d\n", j, dyn.d_tag);
			printf("dyn_addr[%d] = %p\n", j, (void*)&dyn);
			printf("d = %p\n", d);
		}
		//printf("dyn.d_tag = %lu\n", dyn.d_tag);
		//printf("infinity - 1 - rtld_dynamic_tag_val\n");
		if (err){
			printf("infinity - 2 - rtld_dynamic_tag_val\n");
			return err;
		}
		if (dyn.d_tag == DT_NULL){
			printf("infinity - 3 - rtld_dynamic_tag_val\n");
			break;
		}

		if (dyn.d_tag == d_tag){
			printf("infinity - 4 - rtld_dynamic_tag_val\n");
			printf("dyn.d_un.d_val = %u\n", dyn.d_un.d_val);
			return dyn.d_un.d_val;
		}
		//if(i < 30)
		//{
			//break;
		//}
	}
	printf("end - rtld_dynamic_tag_val\n");
	return -ENOENT;
}*/

static int rtld_get_lm(struct process_ctx_s *ctx, uint32_t addr, struct link_map_32_2 *lm)
{
	return process_read_data(ctx, addr, lm, sizeof(*lm));
}

int rtld_needed_array(struct process_ctx_s *ctx, uint64_t _r_debug_addr,
		      uint64_t **needed_array)
{
	struct link_map_32_2 link_map, *lm = &link_map;
	uint32_t lm_addr;
	int err, nr = 0;
	const int step = 10;
	uint64_t *arr = malloc(sizeof(uint64_t) * 10);

	//_r_debug_addr = _r_debug_addr & 0xffffffff;
	printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;_r_debug_addr + offsetof(struct r_debug_32, r_map) = %lx\n", _r_debug_addr + offsetof(struct r_debug_32, r_map));
	err = process_read_data(ctx, _r_debug_addr + offsetof(struct r_debug_32, r_map),
			&lm_addr, sizeof(lm_addr));
	if (err)
		return err;

	do {
		int32_t dt_symtab_addr;

		printf("''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''lm_addr = %x\n", lm_addr);
		err = rtld_get_lm(ctx, lm_addr, lm);
		if (err)
			return err;

		dt_symtab_addr = rtld_dynamic_tag_val(ctx, lm->l_ld, DT_SYMTAB);
		if (dt_symtab_addr == -ENOENT){
			return dt_symtab_addr;
		}
		printf("''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''dt_symtab_addr = %x\n", dt_symtab_addr);
		if (dt_symtab_addr >= (int32_t)lm->l_addr) {
			if ((nr % step) == 0) {
				arr = xrealloc(arr, step * sizeof(uint64_t));
				if (!arr)
					return -ENOMEM;
			}
			arr[nr] = lm_addr;
			arr[nr] = dt_symtab_addr & 0xffffffff;
			if(dt_symtab_addr == 0 || dt_symtab_addr == 0x130)
			{
				arr[nr] = lm_addr;
			}
			printf("''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''arr[nr] = %lx\n", arr[nr]);
			nr++;
		}


		lm_addr = lm->l_next;
	} while (lm_addr);

	*needed_array = arr;

	return nr;

}
