#include <stdint.h>
#include <stdio.h>
#include <link.h>
#include <gelf.h>
#include <errno.h>

#include "include/context.h"
#include "include/process.h"
#include "include/rtld.h"
#include "include/log.h"
#include "include/xmalloc.h"


struct link_map_32_2
{
     /* These first few members are part of the protocol with the debugger.
       This is the same format used in SVR4.  */
	Elf32_Addr l_addr;
	uint32_t l_name;
	uint32_t l_ld;
	uint32_t l_next, l_prev;
};

struct r_debug_32
{
	int r_version;		/* Version number for this protocol.  */
	uint32_t r_map;	/* Head of the chain of loaded objects.  */

	/* This is the address of a function internal to the run-time linker,
	that will always be called when the linker begins to map in a
	library or unmap it, and again when the mapping change is complete.
	The debugger can set a breakpoint at this address if it wants to
	otice shared object mapping changes.  */
	Elf32_Addr r_brk;
	enum
	{
	/* This state value describes the mapping change taking place when
	the `r_brk' address is called.  */
	RT_CONSISTET,		/* Mapping change is complete.  */
	RTADD,			/* Beginning to add a new object.  */
	RT_ELETE		/* Beginning to remove an object mapping.  */
	} r_state;
	
	Elf32_Addr r_ldbase;	/* Base address the linker is loaded at.  */
};

static int rtld_get_dyn_64(struct process_ctx_s *ctx, const void *addr, GElf_Dyn *dyn)
{
	return process_read_data(ctx, (uint64_t)addr, dyn, sizeof(*dyn));
}

static int rtld_get_dyn_32(struct process_ctx_s *ctx, uint32_t addr, Elf32_Dyn *dyn)
{
	return process_read_data(ctx, addr, dyn, sizeof(*dyn));
}

static int64_t rtld_dynamic_tag_val_64(struct process_ctx_s *ctx,
				    const GElf_Dyn *l_ld, uint32_t d_tag)
{
	GElf_Dyn dyn;
	const GElf_Dyn *d;
	int err;

	for (d = l_ld; ; d++) {
		err = rtld_get_dyn_64(ctx, d, &dyn);
		if (err)
			return err;

		if (dyn.d_tag == DT_NULL)
			break;

		if (dyn.d_tag == d_tag)
			return dyn.d_un.d_val;
	}
	return -ENOENT;
}

static int32_t rtld_dynamic_tag_val_32(struct process_ctx_s *ctx,
				    uint32_t l_ld, uint32_t d_tag)
{
	Elf32_Dyn dyn;
	uint32_t d;
	int err;
	for (d = l_ld; ;)
	{
		err = rtld_get_dyn_32(ctx, d, &dyn);
		
		if (err){
			return err;
		}
		if (dyn.d_tag == DT_NULL){
			break;
		}

		if (dyn.d_tag == d_tag){
			return dyn.d_un.d_ptr;
		}
		d += 8;
	}
	return -ENOENT;
}


static int rtld_get_lm_64(struct process_ctx_s *ctx, void *addr, struct link_map *lm)
{
	return process_read_data(ctx, (uint64_t)addr, lm, sizeof(*lm));
}

static int rtld_get_lm_32(struct process_ctx_s *ctx, uint32_t addr, struct link_map_32_2 *lm)
{
	return process_read_data(ctx, addr, lm, sizeof(*lm));
}

int rtld_needed_array_64(struct process_ctx_s *ctx, uint64_t _r_debug_addr,
		      uint64_t **needed_array)
{
	struct link_map link_map, *lm = &link_map;
	void *lm_addr;
	int err, nr = 0;
	const int step = 10;
	uint64_t *arr = NULL;

	err = process_read_data(ctx, _r_debug_addr + offsetof(struct r_debug, r_map),
				&lm_addr, sizeof(lm_addr));
	if (err)
		return err;

	do {
		int64_t dt_symtab_addr;

		err = rtld_get_lm_64(ctx, lm_addr, lm);
		if (err)
			return err;

		/* We rely upon presense of DT_SYMTAB, because it's mandatory */
		dt_symtab_addr = rtld_dynamic_tag_val_64(ctx, lm->l_ld, DT_SYMTAB);
		if (dt_symtab_addr == -ENOENT)
			return dt_symtab_addr;

		/* Check dt_symtab_addr for being above link addr.
		 * This is diferent in VDSO, which has negative or small
		 * address which is offsets from base.
		 */
					
			if (dt_symtab_addr >= (int64_t)lm->l_addr) {
				if ((nr % step) == 0) {
					arr = xrealloc(arr, step * sizeof(uint64_t));
					if (!arr)
						return -ENOMEM;
				}
				arr[nr] = dt_symtab_addr;
				nr++;
			}
			
		lm_addr = lm->l_next;
	} while (lm_addr);

	*needed_array = arr;
	return nr;
}

int rtld_needed_array_32(struct process_ctx_s *ctx, uint64_t _r_debug_addr,
		      uint64_t **needed_array)
{
	struct link_map_32_2 link_map, *lm = &link_map;
	uint32_t lm_addr;
	int err, nr = 0;
	const int step = 10;
	uint64_t *arr = malloc(sizeof(uint64_t) * 10);

	err = process_read_data(ctx, _r_debug_addr + offsetof(struct r_debug_32, r_map),
			&lm_addr, sizeof(lm_addr));
	if (err)
		return err;

	do {
		int32_t dt_symtab_addr;

		err = rtld_get_lm_32(ctx, lm_addr, lm);
		if (err)
			return err;

		dt_symtab_addr = rtld_dynamic_tag_val_32(ctx, lm->l_ld, DT_SYMTAB);
		if (dt_symtab_addr == -ENOENT){
			return dt_symtab_addr;
		}

		if (dt_symtab_addr >= (int32_t)lm->l_addr) {
			if ((nr % step) == 0) {
				arr = xrealloc(arr, step * sizeof(uint64_t));
				if (!arr)
					return -ENOMEM;
			}
			arr[nr] = lm_addr;
			arr[nr] = dt_symtab_addr & 0xffffffff;
			if(dt_symtab_addr == 0 || dt_symtab_addr == 0x130 || dt_symtab_addr == 0xffffe0dc)
			{
				arr[nr] = lm_addr;
			}
			nr++;
		}


		lm_addr = lm->l_next;
	} while (lm_addr);

	*needed_array = arr;

	return nr;
}

int rtld_needed_array(struct process_ctx_s *ctx, uint64_t _r_debug_addr,
		      uint64_t **needed_array)
{
	int nr = 0;
	if(!strcmp(PI(ctx)->patch_arch_type, "EM_X86_64"))
	{
		//printf("needed - 6464646464\n");
		nr = rtld_needed_array_64(ctx, _r_debug_addr, needed_array);
	}

	if(!strcmp(PI(ctx)->patch_arch_type, "EM_386"))
	{
		//printf("needed - 323232323232\n");
		nr = rtld_needed_array_32(ctx, _r_debug_addr, needed_array);
	}

	return nr;
}
