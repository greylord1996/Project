#ifndef __PATCHER_SCM_H__
#define __PATCHER_SCM_H__

int send_fd(int sock, int fd);
int recv_fd(int sock);

#endif /* __PATCHER_SCM_H__ */
