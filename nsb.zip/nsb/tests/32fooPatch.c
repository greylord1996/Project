#include <stdio.h>

int foo()
{
	return 1;
}
