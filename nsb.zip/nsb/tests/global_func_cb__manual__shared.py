#!/usr/bin/env python2
import os

try:
	os.environ['NSB_GENERATOR']
except:
	os.environ['NSB_GENERATOR'] = os.getcwd() + '/generator/nsbgen.py'

try:
	os.environ['NSB_PATCHER']
except:
	os.environ['NSB_PATCHER'] = os.getcwd() + '/nsb'

try:
	os.environ['NSB_TESTS']
except:
	os.environ['NSB_TESTS'] = os.getcwd() + '/tests'

ld_library_path = ""
try:
	ld_library_path = os.environ['LD_LIBRARY_PATH']
except:
	pass

os.environ['LD_LIBRARY_PATH'] = ld_library_path + ":" + os.getcwd() + '/.libs'

os.environ['PYTHONPATH'] = os.getcwd() + '/protobuf'

import sys
sys.path.append(os.path.dirname(os.environ['NSB_GENERATOR']))

import testrunner
exit(testrunner.ExecutableLivePatchTest('nsbtest_shared', 'global_func_cb__manual__shared.patch', True, 'global_func_cb__manual__shared.o', 2, 'manual').run())
