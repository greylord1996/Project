#include <stdio.h>

int foo()
{
	return 0;
}

int main()
{
	while(1)
	{
		foo();
	}

	return 0;
}


