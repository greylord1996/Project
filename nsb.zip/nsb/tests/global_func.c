#include "test_types.h"

long test_global_func(int type)
{
	return function_result(type);
}
